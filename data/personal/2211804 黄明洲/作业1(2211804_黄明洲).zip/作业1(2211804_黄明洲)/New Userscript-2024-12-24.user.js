// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      2024-12-24
// @description  try to take over the world!
// @author       Huang Mingzhou
// @match        https://www.baidu.com/?tn=28114124_1_dg
// @icon         https://www.google.com/s2/favicons?sz=64&domain=baidu.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 定义一个包含常见广告元素选择器的数组
    const selectors = [
        '#s-hotsearch-wrapper',   // 热搜推荐栏
        '#u1 > div:first-child',   // 百度顶部广告（通常是“我爱我家”广告）
        '#s_side_wrapper',         // 右侧广告栏
        '#content_right',          // 右侧广告区域
        '#top-ad',                 // 顶部广告
        '#con-ar',                 // 内容区域的广告
        '#s_wrap'                  // 搜索结果区域广告
    ];

    // 去除广告的函数
    function removeAds() {
        selectors.forEach(selector => {
            // 根据选择器查找对应的元素
            const element = document.querySelector(selector);
            // 如果找到了元素，则将其从 DOM 中移除
            if (element) {
                element.remove();
            }
        });
    }

    // 执行去广告操作
    removeAds();

})();
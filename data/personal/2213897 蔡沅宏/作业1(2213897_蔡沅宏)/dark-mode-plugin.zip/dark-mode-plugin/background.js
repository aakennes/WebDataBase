chrome.runtime.onInstalled.addListener(() => {
    console.log("Dark Mode Plugin 已安装！");
});

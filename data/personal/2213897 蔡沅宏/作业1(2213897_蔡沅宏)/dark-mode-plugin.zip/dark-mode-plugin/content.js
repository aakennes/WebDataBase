// 切换暗模式
document.body.style.backgroundColor = "black";
document.body.style.color = "white";
